#!/usr/bin/env python3
"""Sceglie, in modo deterministico e senza bisogno di salvare uno stato,
un'idea di contenuto per il mese corrente e scrive un file markdown
da usare come corpo di una Issue di GitHub."""
import json
import datetime
import pathlib

base = pathlib.Path(__file__).resolve().parent.parent.parent
with open(base / "content-ideas.json", encoding="utf-8") as f:
    idee = json.load(f)

oggi = datetime.date.today()
indice = (oggi.year * 12 + oggi.month) % len(idee)
idea = idee[indice]

testo = f"""## Promemoria mensile — proposta di contenuto

Questo mese il sistema suggerisce di scrivere un nuovo articolo su:

**{idea}**

Non è un contenuto generato automaticamente: è solo un promemoria.
Scrivilo tu (eventualmente con l'aiuto di Claude per la stesura),
in modo che resti un articolo originale e di qualità — è anche un
requisito per mantenere l'idoneità a Google AdSense.

Quando l'articolo è pubblicato, chiudi pure questa Issue.
"""

with open(base / "report-idea-contenuto.md", "w", encoding="utf-8") as f:
    f.write(testo)
